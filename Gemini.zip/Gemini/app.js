const express = require('express');
const axios = require('axios');

const app = express();

const port = 9000;

// 将助手提交的数据转换成适用于Gemini的数据格式
// 参考以下代码可以接入任何聊天模型

const API_KEY = 'AIzaSyAejIKn1KMe2ta9ujUdy9_DU1der1y4a8M';  // 自行配置Gemini的APIKEY

const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${API_KEY}`;

app.use(express.json());

app.use('/', async (req,res) => {

    // console.log(req.body);
    // 助手提交过来的数据
    // {
    //     messages: [
    //       {
    //         content: '你是ChatGPT，以微信插件形式存在，请以对话方式回应，不要以用户身份回答。',
    //         role: 'system'
    //       },
    //       { content: '你好', role: 'user' }
    //     ],
    //     top_p: 1,
    //     model: 'gpt-3.5-turbo',
    //     stream: false
    //}

    const messages = req.body.messages;
    if (!messages) {
        res.status(400).json({ error: '出错啦' });
        return;
    }
    let contents = [];
    messages.forEach((item,index) => {
        // 插件传递过来的第一条消息是预设，Gemini第一条消息要求是用户，所以当设置预设后添加上一条模型回复的内容
        if (index === 0) {
            contents.push({
                'role':'user',
                'parts':[{'text' :item.content}]
            },{
                'role':'model',
                'parts':[{'text' :'好的'}]
            })
        }else if(index === 1 && item.role === 'assistant') {
            // 由于Gemini接收对话的格式必须是user/model/user/model...，多条对话时插件传递过来的第二条可能会变成assistant所以忽略掉
        }else{
            if (item.role === 'assistant') {
                contents.push({
                    'role':'model',
                    'parts':[{'text' :item.content}]
                });
            }else{
                contents.push({
                    'role':'user',
                    'parts':[{'text' :item.content}]
                });
            }
        }
    });

    try {
        const response = await axios.post(url, {
            'contents':contents
        });
        if (response.data.candidates) {
            res.json({
                'choices': [{
                    'message': {
                        'role': 'assistant',
                        'content': response.data.candidates[0].content.parts[0].text
                    }
                }]
            });
        }else{
            res.status(400).json({ error: '出错啦' });
        }

    }catch (error) {
        res.status(400).json({ error: '出错啦' });
    }
})

app.listen(port,() =>{
    console.log(`服务启动成功http://localhost:${port}`);
})
